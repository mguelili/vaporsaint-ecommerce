MABUHAY ONLINE SERVICES — CISCO PACKET TRACER BUILD KIT
Based on IT204 Final Technical Project, Part E.

IMPORTANT
This kit contains Cisco IOS configuration text and a topology/build guide.
It is NOT a native Cisco Packet Tracer .pkt file. The .pkt format is proprietary
and Packet Tracer is not available in this runtime to create or validate one.
Use the steps below to assemble the topology in Packet Tracer, then paste the
matching configurations into the devices and save the project as .pkt.

SUGGESTED DEVICES
- 1 x Cisco 2911 router (MABUHAY-EDGE; use G0/0 as ISP and G0/1 as trunk)
- 1 x Cisco 2911 router (ISP-ROUTER; use G0/0)
- 1 x Cisco 2960 switch (MABUHAY-CORE-SW)
- 3 x Server-PT: Web, Application, Database
- 1 x Server-PT: SOC Syslog
- 2 x PC-PT: Corporate and Management
- 1 x PC-PT: Guest/Testing

CABLING
- ISP G0/0 <—> EDGE G0/0 (copper straight-through)
- EDGE G0/1 <—> CORE-SW G0/1 (copper straight-through; 802.1Q trunk)
- CORE-SW Fa0/1 <—> Web Server
- CORE-SW Fa0/2 <—> Application Server
- CORE-SW Fa0/3 <—> Database Server
- CORE-SW Fa0/4 <—> Corporate PC
- CORE-SW Fa0/5 <—> SOC Syslog Server
- CORE-SW Fa0/6 <—> Management PC
- CORE-SW Fa0/7 <—> Guest PC

STATIC IPv4 CONFIGURATION
Device/interface            IPv4 address       Default gateway
Web server                  10.10.10.10/24     10.10.10.1
Application server          10.10.20.10/24     10.10.20.1
Database server             10.10.20.20/24     10.10.20.1
Corporate PC                10.10.30.10/24     10.10.30.1
SOC Syslog Server            10.10.40.10/24     10.10.40.1
Management PC               10.10.50.10/24     10.10.50.1
Guest PC                    10.10.60.10/24     10.10.60.1
Core switch VLAN 50 SVI     10.10.50.2/24      10.10.50.1
ISP router G0/0             203.0.113.1/30
Edge router G0/0            203.0.113.2/30

CONFIGURATION ORDER
1. Place and cable devices.
2. Configure ISP router using isp-router.txt.
3. Configure core switch using core-switch.txt.
4. Configure edge router using edge-router.txt.
5. Configure static IP settings on all end devices and servers.
6. On the SOC Server-PT, open Services > SYSLOG and turn the service On.
7. On the Web Server-PT, open Services > HTTP and enable HTTPS if the Packet
   Tracer server model supports it. If not, document the limitation and use
   HTTP only for a classroom demonstration; do not describe that as HTTPS.
8. Save the Packet Tracer project using File > Save As.

TESTS
- From Management PC, ping 10.10.50.1 and SSH to 10.10.50.1.
- From Guest PC, ping 10.10.30.10 and 10.10.20.20: both should be blocked.
- From Corporate PC, ping 10.10.20.20: should be blocked by VLAN30 ACL.
- From Corporate PC, ping SOC server 10.10.40.10: permitted for lab reachability.
- Verify VLANs with: show vlan brief
- Verify trunk with: show interfaces trunk
- Verify router interfaces with: show ip interface brief
- Verify ACL counters with: show access-lists
- Verify routes with: show ip route
- Verify SSH with: show ip ssh
- Check syslog service and generated events on the SOC server.

IMPORTANT DESIGN NOTES
- The sample ACLs demonstrate segmentation principles, not a production-ready
  firewall policy. Review and adapt them to the exact Packet Tracer IOS model.
- The DMZ-to-application permit is TCP/8443; the application-to-database
  permit is TCP/3306. These are illustrative service ports; adjust to the
  application/database actually selected for the lab.
- Packet Tracer does not fully emulate enterprise IDS/IPS behavior. The SOC
  server can demonstrate centralized syslog collection; IDS/IPS alerting may
  need to be represented conceptually or with supported simulation features.
- The sample edge ACL permits inbound TCP/443 to the web host, but this routed
  classroom topology does not implement NAT. If you add NAT or a cloud/ISP
  segment, update addressing and ACLs accordingly.
- The VTY access-class restricts router SSH administration to VLAN 50.
- Change all sample passwords before any real deployment.
